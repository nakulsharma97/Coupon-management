const { app, PORT } = require('./src/app');

app.listen(PORT, () => {
  console.log(`\n🚀 Coupon Management System Started`);
  console.log(`📋 Assignment: Coupon Management`);
  console.log(`🌐 Server running at http://localhost:${PORT}`);
  console.log(`🔑 Required APIs Implemented:`);
  console.log(`   POST /api/coupons           - Create Coupon API`);
  console.log(`   POST /api/coupons/best      - Best Coupon API`);
  console.log(`📋 Optional API:`);
  console.log(`   GET  /api/coupons           - List all coupons (debugging)`);
  console.log(`\n👤 Demo User Context (sample):`);
  console.log(`   Email: hire-me@anshumat.org`);
  console.log(`   Password: HireMe@2025!`);
  console.log(`\n📖 Try these endpoints:`);
  console.log(`   GET  http://localhost:${PORT}/            - Assignment info`);
  console.log(`   GET  http://localhost:${PORT}/health      - Health check`);
  console.log(`   GET  http://localhost:${PORT}/api/coupons - View seeded coupons`);
});
