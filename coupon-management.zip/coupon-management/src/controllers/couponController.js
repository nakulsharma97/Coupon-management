const express = require('express');
const router = express.Router();
const {
  createCoupon,
  listCoupons,
  getBestCoupon
} = require('../services/CouponService');

// Create coupon
router.post('/', (req, res) => {
  try {
    const coupon = createCoupon(req.body);
    res.status(201).json(coupon);
  } catch (err) {
    if (err.status) {
      res.status(err.status).json({ error: err.message });
    } else {
      console.error(err);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  }
});

// Optional: list all coupons
router.get('/', (req, res) => {
  const coupons = listCoupons();
  res.json({ coupons });
});

// Best coupon
router.post('/best', (req, res) => {
  const { userContext, cart } = req.body || {};

  if (!userContext || !cart) {
    return res.status(400).json({ error: 'userContext and cart are required' });
  }

  const best = getBestCoupon(userContext, cart);

  if (!best) {
    return res.json({
      coupon: null,
      discountAmount: 0
    });
  }

  res.json({
    coupon: best.coupon,
    discountAmount: best.discountAmount
  });
});

module.exports = router;
