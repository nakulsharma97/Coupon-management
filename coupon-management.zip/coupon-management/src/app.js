const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const couponRouter = require('./controllers/couponController');
const { seedDemoCoupons } = require('./services/CouponService');

const app = express();
const PORT = process.env.PORT || 3000;

// Middlewares
app.use(cors());
app.use(bodyParser.json());

// Simple assignment info
app.get('/', (req, res) => {
  res.json({
    assignment: 'Coupon Management',
    description: 'Simple Coupon System for e-commerce use case',
    requiredApis: [
      'POST /api/coupons',
      'POST /api/coupons/best'
    ],
    optionalApis: [
      'GET /api/coupons'
    ]
  });
});

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok' });
});

// Coupon routes
app.use('/api/coupons', couponRouter);

// Seed a few demo coupons in memory
seedDemoCoupons();

module.exports = { app, PORT };
