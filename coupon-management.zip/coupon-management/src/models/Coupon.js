class Coupon {
  constructor({
    code,
    description,
    discountType,
    discountValue,
    maxDiscountAmount = null,
    startDate,
    endDate,
    usageLimitPerUser = null,
    eligibility = {}
  }) {
    this.code = code;
    this.description = description;
    this.discountType = discountType; // 'FLAT' or 'PERCENT'
    this.discountValue = discountValue;
    this.maxDiscountAmount = maxDiscountAmount;
    this.startDate = startDate;
    this.endDate = endDate;
    this.usageLimitPerUser = usageLimitPerUser;
    this.eligibility = eligibility;
  }
}

module.exports = Coupon;
