class UserUsage {
  constructor({ userId, couponCode, usageCount = 0 }) {
    this.userId = userId;
    this.couponCode = couponCode;
    this.usageCount = usageCount;
  }
}

module.exports = UserUsage;
