const Coupon = require('../models/Coupon');
const UserUsage = require('../models/UserUsage');

// In-memory stores
const coupons = new Map(); // code -> Coupon
const userUsage = new Map(); // `${userId}:${couponCode}` -> UserUsage

function getUserUsageKey(userId, couponCode) {
  return `${userId}:${couponCode}`;
}

function resetStores() {
  coupons.clear();
  userUsage.clear();
}

function createCoupon(couponData) {
  if (!couponData || !couponData.code) {
    const err = new Error('Coupon code is required');
    err.status = 400;
    throw err;
  }

  const code = String(couponData.code).trim();
  if (coupons.has(code)) {
    const err = new Error('Coupon with this code already exists');
    err.status = 409;
    err.code = 'DUPLICATE_COUPON';
    throw err;
  }

  const coupon = new Coupon({
    code,
    description: couponData.description || '',
    discountType: couponData.discountType,
    discountValue: couponData.discountValue,
    maxDiscountAmount: couponData.maxDiscountAmount ?? null,
    startDate: couponData.startDate,
    endDate: couponData.endDate,
    usageLimitPerUser: couponData.usageLimitPerUser ?? null,
    eligibility: couponData.eligibility || {}
  });

  coupons.set(code, coupon);
  return coupon;
}

function listCoupons() {
  return Array.from(coupons.values());
}

function recordUsage(userId, couponCode) {
  if (!userId || !couponCode) return;
  const key = getUserUsageKey(userId, couponCode);
  const existing = userUsage.get(key) || new UserUsage({ userId, couponCode, usageCount: 0 });
  existing.usageCount += 1;
  userUsage.set(key, existing);
}

function getUsageCount(userId, couponCode) {
  if (!userId || !couponCode) return 0;
  const key = getUserUsageKey(userId, couponCode);
  const entry = userUsage.get(key);
  return entry ? entry.usageCount : 0;
}

function computeCartValue(cart) {
  if (!cart || !Array.isArray(cart.items)) return 0;
  return cart.items.reduce((sum, item) => {
    const price = Number(item.unitPrice) || 0;
    const qty = Number(item.quantity) || 0;
    return sum + price * qty;
  }, 0);
}

function computeItemsCount(cart) {
  if (!cart || !Array.isArray(cart.items)) return 0;
  return cart.items.reduce((sum, item) => {
    const qty = Number(item.quantity) || 0;
    return sum + qty;
  }, 0);
}

function getCartCategories(cart) {
  if (!cart || !Array.isArray(cart.items)) return [];
  const set = new Set();
  for (const item of cart.items) {
    if (item.category) {
      set.add(String(item.category));
    }
  }
  return Array.from(set);
}

function isCouponEligibleForUser(coupon, userContext, cart) {
  const now = new Date();

  // Validity window
  if (coupon.startDate && new Date(coupon.startDate) > now) return false;
  if (coupon.endDate && new Date(coupon.endDate) < now) return false;

  const eligibility = coupon.eligibility || {};
  const cartValue = computeCartValue(cart);
  const itemsCount = computeItemsCount(cart);
  const categories = getCartCategories(cart);

  const userId = userContext && (userContext.userId || userContext.email);

  // Usage limit
  if (coupon.usageLimitPerUser != null && userId) {
    const used = getUsageCount(userId, coupon.code);
    if (used >= coupon.usageLimitPerUser) {
      return false;
    }
  }

  // User-based
  if (eligibility.allowedUserTiers && eligibility.allowedUserTiers.length) {
    if (!userContext || !eligibility.allowedUserTiers.includes(userContext.userTier)) {
      return false;
    }
  }

  if (eligibility.minLifetimeSpend != null) {
    const spend = userContext ? Number(userContext.lifetimeSpend || 0) : 0;
    if (spend < eligibility.minLifetimeSpend) {
      return false;
    }
  }

  if (eligibility.minOrdersPlaced != null) {
    const orders = userContext ? Number(userContext.ordersPlaced || 0) : 0;
    if (orders < eligibility.minOrdersPlaced) {
      return false;
    }
  }

  if (eligibility.firstOrderOnly) {
    const orders = userContext ? Number(userContext.ordersPlaced || 0) : 0;
    if (orders > 0) {
      return false;
    }
  }

  if (eligibility.allowedCountries && eligibility.allowedCountries.length) {
    if (!userContext || !eligibility.allowedCountries.includes(userContext.country)) {
      return false;
    }
  }

  // Cart-based
  if (eligibility.minCartValue != null && cartValue < eligibility.minCartValue) {
    return false;
  }

  if (eligibility.applicableCategories && eligibility.applicableCategories.length) {
    const hasApplicable = categories.some(cat =>
      eligibility.applicableCategories.includes(cat)
    );
    if (!hasApplicable) {
      return false;
    }
  }

  if (eligibility.excludedCategories && eligibility.excludedCategories.length) {
    const hasExcluded = categories.some(cat =>
      eligibility.excludedCategories.includes(cat)
    );
    if (hasExcluded) {
      return false;
    }
  }

  if (eligibility.minItemsCount != null && itemsCount < eligibility.minItemsCount) {
    return false;
  }

  return true;
}

function computeDiscountAmount(coupon, cart) {
  const cartValue = computeCartValue(cart);
  if (cartValue <= 0) return 0;

  let discount = 0;

  if (coupon.discountType === 'FLAT') {
    discount = Number(coupon.discountValue) || 0;
  } else if (coupon.discountType === 'PERCENT') {
    const percent = Number(coupon.discountValue) || 0;
    discount = (percent / 100) * cartValue;
    if (coupon.maxDiscountAmount != null) {
      discount = Math.min(discount, Number(coupon.maxDiscountAmount) || 0);
    }
  }

  if (discount < 0) discount = 0;
  return discount;
}

function getBestCoupon(userContext, cart) {
  const allCoupons = listCoupons();
  let best = null;

  for (const coupon of allCoupons) {
    if (!isCouponEligibleForUser(coupon, userContext, cart)) {
      continue;
    }

    const discountAmount = computeDiscountAmount(coupon, cart);
    if (discountAmount <= 0) continue;

    if (!best) {
      best = { coupon, discountAmount };
      continue;
    }

    if (discountAmount > best.discountAmount) {
      best = { coupon, discountAmount };
      continue;
    }

    if (discountAmount === best.discountAmount) {
      // Tie-breaker 1: earliest endDate
      const currentEnd = coupon.endDate ? new Date(coupon.endDate) : new Date(8640000000000000);
      const bestEnd = best.coupon.endDate ? new Date(best.coupon.endDate) : new Date(8640000000000000);

      if (currentEnd < bestEnd) {
        best = { coupon, discountAmount };
        continue;
      }

      if (currentEnd.getTime() === bestEnd.getTime()) {
        // Tie-breaker 2: lexicographically smaller code
        if (String(coupon.code).localeCompare(String(best.coupon.code)) < 0) {
          best = { coupon, discountAmount };
        }
      }
    }
  }

  return best;
}

function seedDemoCoupons() {
  if (listCoupons().length > 0) return; // avoid reseeding on tests

  const now = new Date();
  const nextMonth = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000).toISOString();
  const yesterday = new Date(now.getTime() - 24 * 60 * 60 * 1000).toISOString();
  const today = now.toISOString();

  createCoupon({
    code: 'WELCOME10',
    description: '10% off for new users',
    discountType: 'PERCENT',
    discountValue: 10,
    maxDiscountAmount: 200,
    startDate: yesterday,
    endDate: nextMonth,
    usageLimitPerUser: 1,
    eligibility: {
      firstOrderOnly: true,
      allowedUserTiers: ['NEW'],
      allowedCountries: ['IN'],
      minCartValue: 500
    }
  });

  createCoupon({
    code: 'FLAT50',
    description: 'Flat ₹50 off on any order over ₹400',
    discountType: 'FLAT',
    discountValue: 50,
    startDate: yesterday,
    endDate: nextMonth,
    eligibility: {
      minCartValue: 400
    }
  });

  createCoupon({
    code: 'ELECTRO15',
    description: '15% off on electronics only',
    discountType: 'PERCENT',
    discountValue: 15,
    maxDiscountAmount: 500,
    startDate: today,
    endDate: nextMonth,
    eligibility: {
      applicableCategories: ['electronics'],
      minCartValue: 1000
    }
  });
}

module.exports = {
  createCoupon,
  listCoupons,
  getBestCoupon,
  recordUsage,
  resetStores,
  seedDemoCoupons,
  computeCartValue,
  computeDiscountAmount
};
