const request = require('supertest');
const { app } = require('../src/app');
const { resetStores, createCoupon } = require('../src/services/CouponService');

describe('Coupon Management APIs', () => {
  beforeEach(() => {
    resetStores();
  });

  test('should create a new coupon successfully', async () => {
    const res = await request(app)
      .post('/api/coupons')
      .send({
        code: 'TEST10',
        description: '10% off',
        discountType: 'PERCENT',
        discountValue: 10,
        startDate: '2024-01-01T00:00:00Z',
        endDate: '2099-12-31T23:59:59Z'
      })
      .expect(201);

    expect(res.body).toHaveProperty('code', 'TEST10');
    expect(res.body).toHaveProperty('discountType', 'PERCENT');
  });

  test('should reject duplicate coupon codes', async () => {
    await request(app)
      .post('/api/coupons')
      .send({
        code: 'DUPLICATE',
        description: 'First one',
        discountType: 'FLAT',
        discountValue: 50,
        startDate: '2024-01-01T00:00:00Z',
        endDate: '2099-12-31T23:59:59Z'
      })
      .expect(201);

    const res = await request(app)
      .post('/api/coupons')
      .send({
        code: 'DUPLICATE',
        description: 'Second one',
        discountType: 'FLAT',
        discountValue: 100,
        startDate: '2024-01-01T00:00:00Z',
        endDate: '2099-12-31T23:59:59Z'
      })
      .expect(409);

    expect(res.body).toHaveProperty('error');
  });

  test('should return best coupon based on discount amount', async () => {
    // Create two coupons
    await createCoupon({
      code: 'FLAT50',
      description: 'Flat 50 off',
      discountType: 'FLAT',
      discountValue: 50,
      startDate: '2024-01-01T00:00:00Z',
      endDate: '2099-12-31T23:59:59Z'
    });

    await createCoupon({
      code: 'PERC10',
      description: '10 percent off',
      discountType: 'PERCENT',
      discountValue: 10,
      startDate: '2024-01-01T00:00:00Z',
      endDate: '2099-12-31T23:59:59Z'
    });

    const res = await request(app)
      .post('/api/coupons/best')
      .send({
        userContext: {
          userId: 'u1',
          userTier: 'NEW',
          country: 'IN',
          lifetimeSpend: 0,
          ordersPlaced: 0
        },
        cart: {
          items: [
            {
              productId: 'p1',
              category: 'electronics',
              unitPrice: 1000,
              quantity: 1
            }
          ]
        }
      })
      .expect(200);

    // FLAT50 => 50 off; PERC10 => 100 off (10% of 1000) => PERC10 should win
    expect(res.body.coupon.code).toBe('PERC10');
    expect(res.body.discountAmount).toBe(100);
  });

  test('should respect eligibility rules (minCartValue, firstOrderOnly)', async () => {
    await createCoupon({
      code: 'WELCOMEONLY',
      description: 'Welcome coupon',
      discountType: 'FLAT',
      discountValue: 100,
      startDate: '2024-01-01T00:00:00Z',
      endDate: '2099-12-31T23:59:59Z',
      eligibility: {
        firstOrderOnly: true,
        minCartValue: 500
      }
    });

    // User with previous orders should not get the coupon
    const res = await request(app)
      .post('/api/coupons/best')
      .send({
        userContext: {
          userId: 'u1',
          userTier: 'NEW',
          country: 'IN',
          lifetimeSpend: 1000,
          ordersPlaced: 2
        },
        cart: {
          items: [
            {
              productId: 'p1',
              category: 'fashion',
              unitPrice: 600,
              quantity: 1
            }
          ]
        }
      })
      .expect(200);

    expect(res.body.coupon).toBeNull();
    expect(res.body.discountAmount).toBe(0);
  });
});
