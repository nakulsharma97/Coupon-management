# Coupon Management System

**Assignment Name:** Coupon Management  

This project implements the backend portion of a coupon management system for an
e-commerce use case, following the requirements from the assignment PDF.

It focuses on:

- Defining a coupon schema with validity window and eligibility rules
- Storing coupons in memory
- Selecting the **best** coupon for a given user & cart
- Providing a clear, deterministic tie-breaking strategy

---

## 1. Tech Stack

- **Language:** Node.js (v18+)
- **Framework:** Express.js (v4.18+)
- **Storage:** In-memory (`Map`)
- **Testing:** Jest + Supertest
- **CORS:** Enabled for all origins

Entry file: `server.js`  
Express app: `src/app.js`  

---

## 2. How to Run

### 2.1 Prerequisites

- Node.js **v18** or higher  
- npm **v9** or higher  

### 2.2 Setup

```bash
git clone <your-repo-url>
cd coupon-management
npm install
```

### 2.3 Running the Application

```bash
npm run dev
# or
npm start
```

By default, the server runs at: `http://localhost:3000`

### 2.4 Health & Info Endpoints

- `GET /` – Assignment info and implemented APIs  
- `GET /health` – Health check  
- `GET /api/coupons` – List in-memory coupons (debugging / optional)  

The main assignment APIs are:

- `POST /api/coupons`
- `POST /api/coupons/best`

---

## 3. Data Model & Inputs

### 3.1 Coupon Schema (Required Fields)

Each coupon follows the schema described in the assignment. At minimum:

- `code` – unique coupon code (e.g. `"WELCOME100"`)
- `description` – short human-readable description
- `discountType` – `"FLAT"` or `"PERCENT"`
- `discountValue`  
  - If `FLAT` → amount off (e.g. `100` means ₹100 off)  
  - If `PERCENT` → percentage (e.g. `10` means 10% off)
- `maxDiscountAmount` *(optional; relevant for `%` discounts)*
- `startDate` and `endDate` – coupon is valid only in this window
- `usageLimitPerUser` *(optional; e.g. `1` = can be used once per user)*
- `eligibility` – object describing who/what this coupon applies to

**Example coupon object:**

```json
{
  "code": "WELCOME100",
  "description": "Flat 100 off for new users",
  "discountType": "FLAT",
  "discountValue": 100,
  "maxDiscountAmount": null,
  "startDate": "2024-01-01T00:00:00Z",
  "endDate": "2024-12-31T23:59:59Z",
  "usageLimitPerUser": 1,
  "eligibility": {
    "firstOrderOnly": true,
    "allowedUserTiers": ["NEW"],
    "minCartValue": 500
  }
}
```

The implementation does **not** add extra fields beyond what is described in the
assignment; it simply uses these fields to drive the eligibility rules.

---

### 3.2 Eligibility Object (Required Supported Fields)

The assignment asks to design an `eligibility` object with the following supported
fields. **All fields are optional** – if a field is not provided, that condition
is ignored.

#### 3.2.1 User-Based Attributes

```json
"eligibility": {
  "allowedUserTiers": ["NEW", "REGULAR", "GOLD"],
  "minLifetimeSpend": 5000,
  "minOrdersPlaced": 3,
  "firstOrderOnly": true,
  "allowedCountries": ["IN", "US"]
}
```

- `allowedUserTiers` – list of allowed user tiers (e.g. `["NEW", "REGULAR", "GOLD"]`)
- `minLifetimeSpend` – minimum total historical spend of the user (e.g. `5000`)
- `minOrdersPlaced` – minimum number of past completed orders (e.g. `3`)
- `firstOrderOnly` – boolean; if `true`, coupon is valid only if this is the user’s first order
- `allowedCountries` – list of country codes (e.g. `["IN", "US"]`)

#### 3.2.2 Cart-Based Attributes

```json
"eligibility": {
  "minCartValue": 500,
  "applicableCategories": ["electronics", "fashion"],
  "excludedCategories": ["grocery"],
  "minItemsCount": 2
}
```

- `minCartValue` – minimum total cart value *before* discount
- `applicableCategories` – list of product categories for which the coupon applies  
  (valid if **at least one** item in the cart is from these categories)
- `excludedCategories` – categories that must **not** appear in the cart
- `minItemsCount` – minimum number of total items in the cart (sum of quantities)

> As allowed by the assignment, no real order-history or lifetime-spend storage is
> implemented. These attributes are simulated as part of the `userContext` input
> to the **Best Coupon API**.

---

### 3.3 Required Inputs for Best Coupon API

The `POST /api/coupons/best` endpoint requires two main inputs: **user context**
and **cart**.

#### 3.3.1 User Context

```json
{
  "userId": "u123",
  "userTier": "NEW",        // e.g. NEW, REGULAR, GOLD
  "country": "IN",
  "lifetimeSpend": 1200,    // total spend so far
  "ordersPlaced": 2         // number of completed orders
}
```

These fields are used to evaluate user-based eligibility rules such as
`allowedUserTiers`, `minLifetimeSpend`, `minOrdersPlaced`, `firstOrderOnly`,
and `allowedCountries`.

#### 3.3.2 Cart

```json
{
  "items": [
    {
      "productId": "p1",
      "category": "electronics",
      "unitPrice": 1500,
      "quantity": 1
    },
    {
      "productId": "p2",
      "category": "fashion",
      "unitPrice": 500,
      "quantity": 2
    }
  ]
}
```

From the `items` array, the service automatically computes:

- **cartValue**: sum of `unitPrice × quantity` for all items  
  (`1500×1 + 500×2 = 2500` in the example)
- **total items count**: sum of `quantity` across all items (`1 + 2 = 3`)
- **distinct categories in cart**: e.g. `["electronics", "fashion"]`

These derived values are used to evaluate `minCartValue`,
`applicableCategories`, `excludedCategories`, and `minItemsCount`.

---

## 4. APIs Implemented (Minimum Requirements)

The project implements the two required APIs and one optional debugging API, as
described in the assignment.

### 4.1 Create Coupon API

**Endpoint:**

```http
POST /api/coupons
```

**Behavior (per assignment):**

- Stores the coupon **in memory** (simple in-process store).
- Uses `code` as the **unique identifier** for each coupon.

**Duplicate Handling (design choice – documented):**

- **Behavior:** Duplicate codes are **rejected**.
- **HTTP Status:** `409 Conflict`
- **Reason:** Prevents accidental overwriting of active promotions and keeps
  coupon configuration explicit and safe.

#### Optional Debugging API

As allowed by the assignment, an optional listing API is also provided:

```http
GET /api/coupons
```

This returns all coupons currently stored in memory and is helpful for
debugging/testing.

---

### 4.2 Best Coupon API

**Endpoint:**

```http
POST /api/coupons/best
```

**Request Body:**

```json
{
  "userContext": {
    "userId": "u123",
    "userTier": "NEW",
    "country": "IN",
    "lifetimeSpend": 1200,
    "ordersPlaced": 2
  },
  "cart": {
    "items": [
      {
        "productId": "p1",
        "category": "electronics",
        "unitPrice": 1500,
        "quantity": 1
      },
      {
        "productId": "p2",
        "category": "fashion",
        "unitPrice": 500,
        "quantity": 2
      }
    ]
  }
}
```

Both `userContext` and `cart` are required. If either is missing, the API
returns `400 Bad Request`.

---

### 4.2.1 Expected Behavior (Mapped to Assignment Steps)

1. **Evaluate all coupons currently stored**  
   The service iterates over every coupon in the in-memory store.

2. **Filter coupons that:**

   1. Are within validity dates  
      `startDate ≤ now ≤ endDate`
   2. Are not exceeding `usageLimitPerUser` for this user  
      (usage is tracked in memory by a key like `userId:couponCode`).
   3. Satisfy **all** eligibility criteria:
      - User-based rules (`allowedUserTiers`, `minLifetimeSpend`,
        `minOrdersPlaced`, `firstOrderOnly`, `allowedCountries`)
      - Cart-based rules (`minCartValue`, `applicableCategories`,
        `excludedCategories`, `minItemsCount`)

3. **For each eligible coupon, compute the discount amount:**

   - If `discountType = "FLAT"`  
     ```text
     discount = discountValue
     ```
   - If `discountType = "PERCENT"`  
     ```text
     discount = (discountValue / 100) * cartValue
     ```
     and if `maxDiscountAmount` is provided:  
     ```text
     discount = min(discount, maxDiscountAmount)
     ```

4. **Select the best coupon using a deterministic rule (as suggested):**

   1. Highest discount amount (primary)
   2. If tie → earliest `endDate` (secondary)
   3. If still tie → lexicographically smaller `code` (final tiebreaker)

5. **Return the best coupon and its computed discount, or `null` if none applies.**

   **Successful response shape:**

   ```json
   {
     "coupon": { /* best coupon object or null */ },
     "discountAmount": 250
   }
   ```

   If no coupon applies:

   ```json
   {
     "coupon": null,
     "discountAmount": 0
   }
   ```

---

## 5. Demo Login / Seeded Demo User (Per Assignment)

The assignment specifies a **demo login** that must be hard-coded in seed data:

- **Email:** `hire-me@anshumat.org`  
- **Password:** `HireMe@2025!`  

In this backend-only implementation:

- There is **no full authentication system** (no real user DB, no sessions/JWT).
- Instead, this demo user is treated as the **canonical example user** for the
  `userContext` when calling `/api/coupons/best`.
- The credentials above are:
  - Logged to the console when the service starts.
  - Used in the README and example cURL commands as the default demo user.

**Example demo user context:**

```json
{
  "userId": "demo_001",
  "email": "hire-me@anshumat.org",
  "userTier": "NEW",
  "country": "IN",
  "lifetimeSpend": 0,
  "ordersPlaced": 0
}
```

In a hosted deployment with a separate auth layer, this user would be seeded
into the user/auth store so that reviewers can log in without registration.

---

## 6. Example Requests

### 6.1 Create Coupon Example

```bash
curl -X POST http://localhost:3000/api/coupons \
  -H "Content-Type: application/json" \
  -d '{
    "code": "MYCOUPON",
    "description": "My test coupon",
    "discountType": "FLAT",
    "discountValue": 25,
    "startDate": "2024-01-01T00:00:00Z",
    "endDate": "2024-12-31T23:59:59Z"
  }'
```

### 6.2 Best Coupon Example (Demo User)

```bash
curl -X POST http://localhost:3000/api/coupons/best \
  -H "Content-Type: application/json" \
  -d '{
    "userContext": {
      "email": "hire-me@anshumat.org",
      "password": "HireMe@2025!",
      "userId": "demo_001",
      "userTier": "NEW",
      "country": "IN",
      "lifetimeSpend": 0,
      "ordersPlaced": 0
    },
    "cart": {
      "items": [
        {
          "productId": "laptop",
          "category": "electronics",
          "unitPrice": 1200,
          "quantity": 1
        }
      ]
    }
  }'
```

---

## 7. Tests

Tests are implemented using **Jest** and **Supertest** in `tests/coupon.test.js`.

To run tests:

```bash
npm test
```

Covered scenarios include:

- Creating a new coupon successfully
- Rejecting duplicate coupon codes (409)
- Choosing the best coupon based on discount amount
- Respecting eligibility rules such as:
  - `firstOrderOnly`
  - `minCartValue`

---

## 8. AI Usage Note

I used AI (ChatGPT) as an assistant to:

- Help structure the Node.js + Express project.
- Draft the `CouponService` logic, including eligibility filtering and
  tie-breaking rules.
- Generate example test cases and documentation sections for this README.

Examples of prompts (paraphrased):

- “Help me implement a coupon management system in Node/Express based on this assignment PDF.”
- “Design eligibility rules and best-coupon selection logic for coupons.”
- “Generate Jest + Supertest tests for the coupon APIs.”

All generated code and text were reviewed and adjusted manually before
submission to ensure understanding and correctness.
